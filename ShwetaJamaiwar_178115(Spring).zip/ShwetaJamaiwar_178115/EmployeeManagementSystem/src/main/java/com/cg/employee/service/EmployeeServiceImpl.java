package com.cg.employee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.employee.dao.EmployeeRepository;
import com.cg.employee.entity.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	private EmployeeRepository employeeRepo;

	/**
	 * Method name : addEmployee
	 * arguements :employee
	 * return type :Employee
	 * purpose :It used to add employee
	 * author : capgemini
	 * date :  24-05-2019
	 */
	@Override
	public Employee addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return employeeRepo.save(employee);
	}
	
	/**
	 * Method name : updateEmployee
	 * return type :Employee
	 * arguements :employee
	 * purpose :It used to update employee by id
	 * author : capgemini
	 * date :  24-05-2019
	 */
	@Override
	public Employee updateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return employeeRepo.save(employee);
	}

	/**
	 * Method name :deleteById
	 * arguements :empId
	 * purpose :It used to delete employee by id
	 * author : capgemini
	 * date :  24-05-2019
	 */
	@Override
	public void deleteById(String empId) {
		// TODO Auto-generated method stub
		employeeRepo.deleteById(empId);
	}

	/**
	 * Method name :viewEmployees
	 * return type :List<Employee>
	 * purpose :It used to view all records of employees 
	 * author : capgemini
	 * date :  24-05-2019
	 */
	@Override
	public List<Employee> viewEmployees() {
		// TODO Auto-generated method stub
	 return employeeRepo.findAll();
	}

	/**
	 * Method name :findById
	 * return type :Employee
	 * arguements :empId
	 * purpose :It will find employee by empId and it will show the details on basis of empId
	 * author : capgemini
	 * date :  24-05-2019
	 */
	@Override
	public Employee findById(String empId) {
		// TODO Auto-generated method stub
		return employeeRepo.findById(empId).get();
	}

}
