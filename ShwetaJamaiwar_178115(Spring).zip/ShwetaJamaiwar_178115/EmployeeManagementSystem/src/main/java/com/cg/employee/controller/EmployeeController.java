package com.cg.employee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.employee.entity.Employee;
import com.cg.employee.service.EmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	EmployeeService service;
	@Autowired
	Employee employee;
	
	/**
	 * Method name : addEmployee
	 * return type :Employee
	 * Post Request Used
	 * author : capgemini
	 * date :  24-05-2019
	 */
	@PostMapping(value="/addEmployee",consumes= {MediaType.APPLICATION_JSON_VALUE})
	public Employee addEmployee(@RequestBody Employee employee) {
		Employee addEmployeeDetails=service.addEmployee(employee);
		return addEmployeeDetails;
	}
	
	/**
	 * Method name : updateEmployee
	 * return type :String
	 * Put Request Used
	 * author : capgemini
	 * date :  24-05-2019
	 */
	@PutMapping(value="/updateEmployee/{empId}",consumes= {MediaType.APPLICATION_JSON_VALUE})
	public String updateEmployee(@RequestBody Employee employee) {
		Employee updateEmployeeDetails=service.updateEmployee(employee);
		return employee+"Employee Updated";
		
	}
	
	/**
	 * Method name : deleteByEmpId
	 * return type :String
	 * Delete Request Used
	 * author : capgemini
	 * date :  24-05-2019
	 */
	@DeleteMapping("/deleteByEmpId/{empId}")
	public String deleteByEmpId(@PathVariable String empId) {
		service.deleteById(empId);
		return empId +"/t"+"Employee Deleted";
	}
	
	/**
	 * Method name : viewEmployees
	 * return type :List<Employee>
	 * Get Request Used
	 * author : capgemini
	 * date :  24-05-2019
	 */
	@GetMapping("/viewEmployees")
	public List<Employee> viewEmployees(){
		return service.viewEmployees();
	}
	
	/**
	 * Method name : findByEmpId
	 * return type :Employee
	 * Get Request Used
	 * author : capgemini
	 * date :  24-05-2019
	 */
	@GetMapping("/findByEmpId/{empId}")
	public Employee findByEmpId(@PathVariable String empId) {
		return service.findById(empId);
	}
}
