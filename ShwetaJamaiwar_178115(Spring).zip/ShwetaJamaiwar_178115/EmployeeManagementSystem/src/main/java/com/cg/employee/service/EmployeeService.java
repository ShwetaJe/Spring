package com.cg.employee.service;

import java.util.List;

import com.cg.employee.entity.Employee;

public interface EmployeeService {
	public Employee addEmployee(Employee employee);
	public Employee updateEmployee(Employee employee);
	public void deleteById(String empId);
	public List<Employee>viewEmployees();
	public Employee findById(String empId);
}
