package com.cg.employee.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name="Employee")
@Component
public class Employee {
	@Id
	
	private String empId;
	private String name;
	private String designation;
	private String deptName;
	private int salary;
	
	/**
	 * Constructor name :Employee(Default Constructor)
	 * return type : no return type
	 * author : capgemini
	 * date :  24-05-2019
	 */
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * Constructor name :Employee(Parameterized Constructor)
	 * return type : no return type
	 * arguments: String empId, String name, String designation, String deptName, int salary
	 * author : capgemini
	 * date :  24-05-2019
	 */
	public Employee(String empId, String name, String designation, String deptName, int salary) {
		super();
		this.empId = empId;
		this.name = name;
		this.designation = designation;
		this.deptName = deptName;
		this.salary = salary;
	}
	
	//Setters and Getters
	
	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	
	/**
	 * Method name :toString
	 * return type :String
	 * author : capgemini
	 * date :  24-05-2019
	 */
	@Override
	public String toString() {
		return "Employee [EmpId=" + empId + ", Name=" + name + ", Designation=" + designation + ", DeptName=" + deptName
				+ ", Salary=" + salary + "]";
	}
}
